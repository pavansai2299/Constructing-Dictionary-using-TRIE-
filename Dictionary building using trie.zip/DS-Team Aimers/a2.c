/*Including the required standard libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

/*Declaring the global variables*/
int i=0;
char line [128];
char str[170][128];
char str1[170][128];
char str2[170][128];

/*Copying the dictionary words in file to strings */
void FileReading()
{
	int j,l,p,temp,r,m,temp1;
	FILE *file = fopen ("DictionaryWords.txt", "r" );
	while(fgets(line, sizeof line, file) != NULL)
	{
		strcpy(str[i],line);//coying each line in file to str
		i++;
	}

	fclose(file);//closing the file
	for(j=0;j<i;j++)
	{
		l=strlen(str[j]);
		for(p=0;p<l;p++)
		{
			if(str[j][p]=='-')  //travelling upto the ("-")
			{
				temp=p;
				for(r=0;r<temp;r++)
				{
					str1[j][r]=str[j][r];
				}
				str1[j][r]='\0';
				temp1=0;
				for(m=temp+1;m<l;m++)
				{
					str2[j][temp1]=str[j][m];
					temp1++;
				}
				str2[j][temp1]='\0';	
			} 	
		}

	}
}

/*Updating the old-meaning with new-meaning*/
void updatemeaning(TRIE *root,char word[],char umeaning[])
{
	int level,length,index;
	length=strlen(word);
	TRIE *trie=root;
	for(level=0;level<length;level++)
	{
		index=C2I(word[level]);       //converting character into integer
		//trie=trie->children[index];
		if(!trie->children[index])
		{
			printf("No such word\n");
			//return 0;
			//exit(-1);
			trie=NULL;
			break;    
		}
		trie=trie->children[index];
	}
	if(trie!=NULL)
		strcpy(trie->meaning,umeaning);
}

