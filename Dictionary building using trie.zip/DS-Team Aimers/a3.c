#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#define GETSIZE(a) sizeof(a)/sizeof(a[0])
#define CHARSET_SIZE (26)
#define FREE(p) \
	free(p);    \
p=NULL;
/*int leafNode(TRIE *pNode)
{
	return (pNode->isLeaf != false);
}
int isItFreeNode(TRIE *pNode)
{
	int i;
	for(i = 0; i < CHARSET_SIZE; i++)
	{
		if( pNode->children[i] )
		{
			return 0;
		}

	}

	return 1;
}
bool delete(TRIE *trie,char key[],int level,int len)
{
	if(trie!=NULL)
	{
		if(level==len)
		{
			if(trie->isLeaf==true)
			{
				trie->isLeaf=false;
				if(isItFreeNode(trie))
				{
					return true;
				}   
				else
				{
					return false;
				}
			}
		}
		else
		{
			int index = C2I(key[level]);

			if( delete(trie->children[index], key, level+1, len) )
			{
				FREE(trie->children[index]);
				return ( !leafNode(trie) && isItFreeNode(trie) );
			}
		}
	}   
	else
	{
		return false;
	}                       
}
void deletekey(TRIE *root, char key[])
{
	printf("deleting the word %s\n",key);
	int len = strlen(key);
	TRIE *trie=root;
	if( len > 0 )
	{
		delete(trie, key, 0, len);
	}
}*/   

int Issuffix(char string[],char *suffix)
{
	int len1=strlen(suffix),len2=strlen(string),i,j=0;
	char pre[10];
	for(i=len2-len1;i<len2;i++)
	{
		pre[j]=string[i];
		j++;

	}
	pre[j]='\0';
	if(strcmp(suffix,pre)==0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int count=0;
void printWordsWithCommonsuffix(TRIE *root,char str[][100],int j,char suffix[])
{
	if(count==0)
	{
		printf("--------printing words with given common suffix '%s'----------\n",suffix);
		count++;
	}
	TRIE *trie=root;
	if(trie->isLeaf==true && Haschild(trie)!=1)
	{
		str[0][j]='\0';
		if(Issuffix(str[0],suffix)==1)
		{
			printf("%s\n",str[0]);
		}
		for(int i=0;i<CHARSET_SIZE;i++)
		{
			if(trie->children[i]!=NULL)
			{
				str[0][j]=I2C(i);
				printWordsWithCommonsuffix(trie->children[i],str,j+1,suffix);
			}
		}
	}
	else
	{
		for(int i=0;i<CHARSET_SIZE;i++)
		{
			if(trie->children[i]!=NULL)
			{
				str[0][j]=I2C(i);
				printWordsWithCommonsuffix(trie->children[i],str,j+1,suffix);
			}
		}
	}
}
char ds[50][50];
int s=0;
void deletesuffix(TRIE *root)
{
	int i;
	for(i=0;i<s;i++)
	{
		deletekey(root,ds[i]);
	}
}
void deleteWordsWithCommonsuffix(TRIE *root,char str[][100],int j,char suffix[])
{
	TRIE *trie=root;
	if(trie->isLeaf==true && Haschild(trie)!=1)
	{
		str[0][j]='\0';
		if(Issuffix(str[0],suffix)==1)
		{
			strcpy(ds[s],str[0]);
			s++;
		}
		for(int i=0;i<CHARSET_SIZE;i++)
		{
			if(trie->children[i]!=NULL)
			{
				str[0][j]=I2C(i);
				deleteWordsWithCommonsuffix(trie->children[i],str,j+1,suffix);
			}
		}
	}
	else
	{
		for(int i=0;i<CHARSET_SIZE;i++)
		{
			if(trie->children[i]!=NULL)
			{
				str[0][j]=I2C(i);
				deleteWordsWithCommonsuffix(trie->children[i],str,j+1,suffix);
			}
		}
	}
}
int Issubstring(char str[50], char *key)
{

	int i,j,k;	
	for(j=0,k=0;j<strlen(str)&& k<strlen(key);j++)
	{
		if( str[j]==key[k])
		{
			k++;

		}	
	}
	if(k==strlen(key))
	{	
		return 1;
	}
	else
	{
		return 0;
	}
}
int count1=0;
void printWordsWithGivenSubString(TRIE *root,char str[][100],int j,char substring[])
{
	if(count1==0)
	{
		printf("--------printing words with given substring '%s'----------\n",substring);
		count1++;
	}
	TRIE *trie=root;
	if(trie->isLeaf==true && Haschild(trie)!=1)
	{
		str[0][j]='\0';
		if(Issubstring(str[0],substring)==1)
		{
			printf("%s\n",str[0]);
		}
		for(int i=0;i<CHARSET_SIZE;i++)
		{
			if(trie->children[i]!=NULL)
			{
				str[0][j]=I2C(i);
				printWordsWithGivenSubString(trie->children[i],str,j+1,substring);
			}
		}
	}
	else
	{
		for(int i=0;i<CHARSET_SIZE;i++)
		{
			if(trie->children[i]!=NULL)
			{
				str[0][j]=I2C(i);
				printWordsWithGivenSubString(trie->children[i],str,j+1,substring);
			}
		}
	}
}

