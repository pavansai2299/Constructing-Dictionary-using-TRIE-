// TRIE Data Structure
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define GETSIZE(a) sizeof(a)/sizeof(a[0])
#define CHARSET_SIZE (26)
#define FREE(p) \
	free(p);    \
p=NULL;
typedef struct trie {
	struct trie *children[CHARSET_SIZE];
	bool isLeaf;     // To Identify the end of a word
	//char meaning[1000];Change this to a pointer to char type
	char meaning[100];
} TRIE;

// This function converts key into index -  lower case letters 'a - z'
// #define C2I(c) ((int)c - (int)'a')
int C2I(char ch) {
	if((int)ch>=97 && (int)ch<=123)
		return (int)ch - (int)'a';
	//else
	//return (int)ch - (int)'A';
}

char I2C(int n)
{
	return (int)'a'+n;
}

// Create TRIE Data Structures
TRIE *getNode(void) {
	TRIE *cnode = NULL;

	cnode = (TRIE *)malloc(sizeof(TRIE));
	if (cnode) {
		int i;
		cnode->isLeaf = false;

		for (i = 0; i < CHARSET_SIZE ; i++)
			cnode->children[i] = NULL;
	}
	return cnode;
}

// Inserts key into trie, if not present; else mark the leaf node
/*void insert(TRIE *root, const char *key) {
	int level, index, length;
	length = strlen(key);
	TRIE *cnode = root;
	for (level = 0; level < length; level++) {
		index = C2I(key[level]);
		if (!cnode->children[index])
			cnode->children[index] = getNode();
		cnode = cnode->children[index];
	}
	// last node is marked as the leaf node
	cnode->isLeaf = true;
}*/

void insertWithMeaning(TRIE *root,const char *key,char mean[]) {
	int level,index,length;
	length=strlen(key);
	TRIE *cnode=root;
	for(level=0;level<length;level++) {
		index=C2I(key[level]);
		if(!cnode->children[index])
			cnode->children[index]=getNode();
		cnode=cnode->children[index];
	}
	cnode->isLeaf=true;
	//cnode->meaning=(char *)malloc(sizeof(char));
	strcpy(cnode->meaning,mean);
}


// Returns true if key presents in trie, else false
bool search(TRIE *root, const char *key) {
	//printf("searching for the word %s: ",key);
	int level, length, index;
	length = strlen(key);
	TRIE *trie = root;

	for (level = 0; level < length; level++) {
		index = C2I(key[level]);

		if (!trie->children[index])
			return false;
		trie = trie->children[index];
	}

	return (trie != NULL && trie->isLeaf);
}

bool searchword(TRIE *root,const char *key)
{
	printf("searching for the word %s: ",key);
	search(root,key);
}
void getmeaning(TRIE *root,char word[])
{
	printf("meaning of the word %s:",word);
	int level,length,index;
	length=strlen(word);
	TRIE *trie=root;
	for(level=0;level<length;level++)
	{
		index=C2I(word[level]);
		//trie=trie->children[index];
		if(!trie->children[index])
		{
			printf("No such word\n");
			//return 0;
			//exit(-1);
			trie=NULL;
			break;    
		}
		trie=trie->children[index];
	}
	if(trie!=NULL)
		printf("%s\n",trie->meaning);
}
int leafNode(TRIE *pNode)
{
	return (pNode->isLeaf != false);
}
int isItFreeNode(TRIE *pNode)
{
	int i;
	for(i = 0; i < CHARSET_SIZE; i++)
	{
		if( pNode->children[i] )
		{
			return 0;
		}

	}

	return 1;
}
int Haschild(TRIE *root)
{
	int i,count=0;
	for(i=0;i<27;i++)
	{
		if(root->children[i]!=NULL)
		{
			count++;
		}
	}
	if(count==0)
	{
		return 1;
	}
	else
	{
		return 0;
	}       
}

bool delete(TRIE *trie,char key[],int level,int len)
{
	if(trie!=NULL)
	{
		if(level==len)
		{
			if(trie->isLeaf==true)
			{
				trie->isLeaf=false;
				if(isItFreeNode(trie))
				{
					return true;
				}   
				else
				{
					return false;
				}
			}
		}
		else
		{
			int index = C2I(key[level]);

			if( delete(trie->children[index], key, level+1, len) )
			{
				FREE(trie->children[index]);
				return ( !leafNode(trie) && isItFreeNode(trie) );
			}
		}
	}   
	else
	{
		return false;
	}                       
}
void deletekey(TRIE *root, char key[])
{
	printf("deleting the word %s\n",key);
	int len = strlen(key);
	TRIE *trie=root;
	if( len > 0 )
	{
		delete(trie, key, 0, len);
	}
}    
char string[100][100];
int d=0;
void checkspell(char string[][100],char *word)
{
	int i,count=0,j,p,count1=0;
	char str[100];
	for(p=0;p<d;p++){
		strcpy(str,string[p]);
		if(strcmp(str,word)==0)
		{
			printf("'%s' exists in the dictionary\n",str);
			count1++;
			break;
		}
	}
	if(count1==0){
	for(j=0;j<d;j++){
		strcpy(str,string[j]);
		if(strlen(str)==strlen(word))
		{
			for(i=0;i<strlen(str);i++)
			{
				if(str[i]!=word[i])
				{
					count++;
				}
			}
			if(count<4)
			{
				printf("%s\n",str);
			}

		}
		else
		{
			if(Issubstring(str,word)==1)
			{
				printf("%s\n",str);
			}
		}
	}
}
}
void printwords(TRIE *root,char str[][100],int j)
{
	TRIE *trie=root;
	if(trie->isLeaf==true && Haschild(trie)!=1)
	{
		str[0][j]='\0';

		//strcpy(string[d],str[0]);
		//d++;
		printf("%s\n",str[0]);
		for(int i=0;i<CHARSET_SIZE;i++)
		{
			if(trie->children[i]!=NULL)
			{
				str[0][j]=I2C(i);
				printwords(trie->children[i],str,j+1);
			}
		}
	}
	else
	{
		for(int i=0;i<CHARSET_SIZE;i++)
		{
			if(trie->children[i]!=NULL)
			{
				str[0][j]=I2C(i);
				printwords(trie->children[i],str,j+1);
			}
		}
	}
}

int spell=0;
void SuggestWords(TRIE *root,char str[][100],int j,char *word)
{
	if(spell==0)
	{
		printf("------------suggesting correct words for '%s'----------------------\n",word);
		spell++;
	}
	TRIE *trie=root;
	if(trie->isLeaf==true && Haschild(trie)!=1)
	{
		str[0][j]='\0';

		strcpy(string[d],str[0]);
		d++;
		//printf("%s\n",str[0]);
		//checkspell(str[0],word);
		for(int i=0;i<CHARSET_SIZE;i++)
		{
			if(trie->children[i]!=NULL)
			{
				str[0][j]=I2C(i);
				SuggestWords(trie->children[i],str,j+1,word);
			}
		}
	}
	else
	{
		for(int i=0;i<CHARSET_SIZE;i++)
		{
			if(trie->children[i]!=NULL)
			{
				str[0][j]=I2C(i);
				SuggestWords(trie->children[i],str,j+1,word);
			}
		}
	}
}
