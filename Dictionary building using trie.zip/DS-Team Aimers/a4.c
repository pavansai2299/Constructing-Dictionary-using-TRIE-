
char prefix[100][100];
int x=0;
//Function to call the "deletekey" function to delete the words.
void callit(TRIE *root)
{
	int i;
	for(i=0;i<x;i++)							//"x" is number of words with the given string as prefix.
		deletekey(root,prefix[i]);
}

void  findWords(TRIE *root,int j,char A[],int i,TRIE *trie) 
{
	int k;
	if(root->isLeaf==true)
	{
		A[i]=I2C(j);
		A[i+1]='\0';
		printf("%s,",A);
		getmeaning(trie,A);							//Calling the "getmeaning" function to print the meaning  of the word.

	}
	A[i]=I2C(j);
	for(k=0;k<CHARSET_SIZE;k++)
		if(root->children[k])
			findWords(root->children[k],k,A,i+1,trie); 
}

//Function to find all the words with a given prefix.
void findPrefix(TRIE *root,const char *key)
{
	printf("----------------searching for words with common prefix '%s'-------------------\n",key);
	int l,index,j,k=1,i,c=0;
	char A[1000],B[1000];
	TRIE *trie=root;
	l=strlen(key);
	for(i=0;i<l;i++)
	{
		index=C2I(key[i]);
		if(!trie->children[index])							//If there is no word with given string as prefix.
		{
			printf("No word with '%s' as preffix\n", key);
			k=0;
			break;
		}	
		A[i]=key[i];
		trie=trie->children[index];
	}
	if(k==1)
	{
		A[i]='\0';
		if(search(root,A)==1)						//Calling the "search" function to find given prefix in the dictionary.
		{
			printf("%s,",A);
			getmeaning(root,A);
		}
		for(j=0;j<CHARSET_SIZE;j++)
			if(trie->children[j])
				findWords(trie->children[j],j,A,i,root);		//Calling the function, "findWords" to find all the words with 'A' as prefix.
	}
}
void  deleteWords(TRIE *root,int j,char A[],int i,TRIE *trie) 
{
	int k;
	if(root->isLeaf==true)
	{
		A[i]=I2C(j);
		A[i+1]='\0';
		strcpy(prefix[x],A);
		x++;
	}
	A[i]=I2C(j);
	for(k=0;k<CHARSET_SIZE;k++)
		if(root->children[k])
			deleteWords(root->children[k],k,A,i+1,trie); 
}

//Function to find all the words with a given prefix,to delete.
void DeleteWordsWithCommonPrefix(TRIE *root,const char *key)
{
	printf("-------------------Deleting the words with prefix %s----------------------\n",key);
	int l,index,j,k=1,i,c=0;
	char A[1000],B[1000];
	TRIE *trie=root;
	l=strlen(key);
	for(i=0;i<l;i++)
	{
		index=C2I(key[i]);
		if(!trie->children[index])								//If there is no word with given string as prefix.						
		{
			printf("No word with '%s' as preffix\n", key);
			k=0;
			break;
		}	
		A[i]=key[i];
		trie=trie->children[index];
	}
	if(k==1)
	{
		A[i]='\0';
		if(search(root,A)==1)									//Calling the "search" function to find given prefix in the dictionary.
		{
			strcpy(prefix[x],A);								//Copying 'A' to a globally declared string,"prefix".
			x++;
		}
		for(j=0;j<CHARSET_SIZE;j++)
			if(trie->children[j])
				deleteWords(trie->children[j],j,A,i,root);		//Calling the function, "deleteWords" to find all the words with 'A' as prefix,to delete.
	}
	callit(root);
}
