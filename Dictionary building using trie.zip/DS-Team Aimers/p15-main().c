#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include"a1.c"
#include"a2.c"
#include"a3.c"
#include"a4.c"
int main()
{
int q;
FileReading();
for(q=0;q<i;q++)
	{
		printf("inserting: %s",str1[q]);
		insertWithMeaning(root,str1[q],str2[q]);
		printf("\n");
	}
	printf("\n");
	for(q=0;q<i;q++)
	{
		getmeaning(root,str1[q]);
	}
	updatemeaning(root,"ugly","atrractive");
	getmeaning(root,"ugly");
	printf("\n");
	printf("%s\n\n",message[searchword(root,"ugly")]);
	deletekey(root,"ugly");
	printf("\n");
	printf("%s\n",message[searchword(root,"ugly")]);
	printf("\n");
	findPrefix(root,"qu");
	DeleteWordsWithCommonPrefix(root,"qu");
	printf("---------------------------words in dictionary-----------------------------\n");
	printwords(root,str3,0);
	printWordsWithCommonsuffix(root,str3,0,"al");
	printf("--------------------------------\n");
	deleteWordsWithCommonsuffix(root,str3,0,"ya");
	deletesuffix(root);
	printf("--------------------------------\n");
	printwords(root,str3,0);
	printWordsWithGivenSubString(root,str3,0,"er");
	SuggestWords(root,str3,0,"ami");
	checkspell(string,"ami");
	return 0;
}
